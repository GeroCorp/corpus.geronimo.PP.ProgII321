package sistemagestionparcial;

public interface Explorador {
    void explorar();
}
