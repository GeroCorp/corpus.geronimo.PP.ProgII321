package sistemagestionparcial;

public class NaveExploracion extends NaveEspacial implements Explorador{
    
    private Tipo tipoMision;

    public NaveExploracion(Tipo tipoMision, String nombre, int capacidadTripulacion, int anioLanzamiento) {
        super(nombre, capacidadTripulacion, anioLanzamiento);
        this.tipoMision = tipoMision;
    }
    
    
    
    @Override
    public void explorar() {
        System.out.println("Nave de exploracion:"+getNombre()+" iniciando exploracion...");
    }

    @Override
    public String toString() {
        return super.toString() + ", NaveExploracion{" + "tipoMision=" + tipoMision + "} }";
    }

    

    

    
    
}
