package sistemagestionparcial;

public class CruceroEstelar extends NaveEspacial{

    private int cantidadPasajeros;

    public CruceroEstelar(int cantidadPasajeros, String nombre, int capacidadTripulacion, int anioLanzamiento) {
        super(nombre, capacidadTripulacion, anioLanzamiento);
        this.cantidadPasajeros = cantidadPasajeros;
    }

    @Override
    public String toString() {
        return super.toString() + ", CruceroEstelar{" + "cantidadPasajeros=" + cantidadPasajeros + '}';
    }
    
    

        
}
