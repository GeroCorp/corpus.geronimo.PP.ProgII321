package sistemagestionparcial;

import java.util.ArrayList;
import java.util.List;

public class Agencia {
    private List<NaveEspacial> naves;

    public Agencia() {
        naves = new ArrayList<>();
    }
    
    public void agregarNave (NaveEspacial n){
        if (n == null){
            throw new NullPointerException("No se ha ingresado una nave.");
        }
        if (naves.contains(n)){
            throw new NaveRepetidaException();
        }
        naves.add(n);
    }
    
    public void MostrarNaves (){
        if (!(naves.isEmpty())){
            for (NaveEspacial n: naves){
                System.out.println(n);
            }
        }else{
            System.out.println("Lista de naves vacia.");
        }
    }
    
    public void iniciarExploracion() {
        for (NaveEspacial n:naves){
            if (n instanceof Explorador){
                ((Explorador)n).explorar();
            }
        }
    }
    
}
