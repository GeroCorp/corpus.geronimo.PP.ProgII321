package sistemagestionparcial;

public class SistemaGestionParcial {

    public static void main(String[] args) {
        Agencia a = new Agencia();
        
        NaveExploracion ne1 = new NaveExploracion(Tipo.INVESTIGACION, "ne1", 110, 200);
        NaveExploracion ne2 = new NaveExploracion(Tipo.INVESTIGACION, "ne2", 110, 200);
        NaveCarguera nc1 = new NaveCarguera("nc1", 100, 200);
        NaveCarguera nc2 = new NaveCarguera("nc2", 100, 200);
        
        nc1.setCapacidadCarga(200);
        nc2.setCapacidadCarga(400);
        
        try{
        a.agregarNave(ne1);
        a.agregarNave(ne2);
        a.agregarNave(nc1);
        a.agregarNave(nc2);
        }catch(NullPointerException ex){
            System.out.println(ex.getMessage());
        }catch(NaveRepetidaException ex){
            System.out.println(ex.getMessage());
        }
        
        a.MostrarNaves();
        a.iniciarExploracion();
    }
    
}
