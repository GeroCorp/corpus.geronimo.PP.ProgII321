package sistemagestionparcial;

public class NaveCarguera extends NaveEspacial implements Explorador{

    private int capacidadCarga;
    private final int CAPACIDAD_MAX = 500;
    private final int CAPACIDAD_MIN = 100;

    public NaveCarguera(String nombre, int capacidadTripulacion, int anioLanzamiento) {
        super(nombre, capacidadTripulacion, anioLanzamiento);
    }

    public void setCapacidadCarga(int capacidadCarga) {
        if (capacidadCarga < CAPACIDAD_MIN || capacidadCarga > CAPACIDAD_MAX){
            throw new RuntimeException("Capacidad de carga invalida.");
        }
        this.capacidadCarga = capacidadCarga;
    }
    
    
    
    @Override
    public void explorar() {
        System.out.println("Nave carguera:"+getNombre()+" iniciando exploracion...");    
    }

    @Override
    public String toString() {
        return super.toString() +  ", NaveCarguera{" + "capacidadCarga=" + capacidadCarga + "} }";
    }

    

    
    
}
