package sistemagestionparcial;

public class NaveRepetidaException extends RuntimeException {
    private static final String MESSAGE = "Nave ingresada repetida.";

    public NaveRepetidaException() {
        super(MESSAGE);
    }
    
    
}
