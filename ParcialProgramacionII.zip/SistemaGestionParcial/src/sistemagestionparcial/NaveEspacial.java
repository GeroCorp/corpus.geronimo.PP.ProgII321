package sistemagestionparcial;

import java.util.Objects;

public abstract class NaveEspacial {
    private String nombre;
    private int capacidadTripulacion;
    private int anioLanzamiento;

    public NaveEspacial(String nombre, int capacidadTripulacion, int anioLanzamiento) {
        this.nombre = nombre;
        this.capacidadTripulacion = capacidadTripulacion;
        this.anioLanzamiento = anioLanzamiento;
    }

    public String getNombre() {
        return nombre;
    }

    @Override
    public String toString() {
        return "NaveEspacial{" + "nomnbre=" + nombre + ", capacidadTripulacion=" + capacidadTripulacion + ", anioLanzamiento=" + anioLanzamiento;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 71 * hash + Objects.hashCode(this.nombre);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (obj instanceof String str){
            return nombre.equals(str);
        }
        if (obj instanceof NaveEspacial other){
            return this.nombre.equals(other.nombre);
        }
        return false;
    }

    
    

    
    
    
    
    
    
}
