package sistemagestionparcial;

public enum Tipo {
    CARTOGRAFIA,
    INVESTIGACION,
    CONTACTO
}
